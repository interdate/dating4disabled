Changelog
=========

v1.2.0
------
b7d1afd - Made sure we have a object as `settings`. Added small readme adjustments. [marcj]
05ccb3c - Restoring dropdown state after calling 'refresh'. Fixes marcj/jquery-selectBox#85. [Pavel Horal]
34845fb - Cleaned. [marcj]
3441eba - Cleaned more code/text. [marcj]
b748694 - Fixed the `setOptions` method, where the wrong variable has been used. [marcj]
cf61fdd - Implemented a `mobile` switch. Added prettified settings table. Fixed #111 [marcj]
fe46e1e - Cleaned/Refactored the javascript/css code. Compressed the newest version into `min.js`. [marcj]
99c004c - Updated for ownership transfer [Cory LaViska]
1e9224d - Updated readme [Cory LaViska]
f12ac8f - Fix init parameters [Simon Garner]
5c4ad19 - Fix type-to-find behaviour [Simon Garner]
a942b05 - Updated readme [Cory LaViska]
e0ccf35 - Updated readme [Cory LaViska]
648c1c9 - IE7 js error fix (tabindex cannot be NaN) [MAJESTIC]
dfa5a4d - Changed Tab characters. [Uriy Efremochkin]
662c382 - Fix the bug with incorrect calculation of the Label width. [Uriy Efremochkin]
f8c1551 - added check for mouse button to mouseup events as well [Haralan Dobrev]
b63f367 - added checks for the button clicked on mousedown events [Haralan Dobrev]
